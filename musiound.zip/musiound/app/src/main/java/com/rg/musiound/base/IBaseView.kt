package com.rg.musiound.base

/**
 * Create by yuanbing
 * on 2019/8/1
 */
interface IBaseView
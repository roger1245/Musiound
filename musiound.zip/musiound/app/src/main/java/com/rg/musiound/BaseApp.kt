package com.rg.musiound

import android.app.Application

/**
 * Create by roger
 * on 2019/8/15
 */
class BaseApp : Application() {

    override fun onCreate() {
        super.onCreate()
    }
}
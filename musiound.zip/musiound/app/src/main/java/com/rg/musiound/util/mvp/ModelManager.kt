package com.rg.musiound.util.mvp

import com.rg.musiound.base.IBaseModel

/**
 * Create by yuanbing
 * on 2019/8/1
 */
object ModelManager {
    private val mModels: HashMap<Class<out IBaseModel>, out IBaseModel> = HashMap()

    
}
package com.rg.musiound.base

/**
 * Create by yuanbing
 * on 2019/8/1
 */
abstract class BaseModel: IBaseModel {
    /**
     * 默认不做任何操作
     */
    override fun onStop() {}
}